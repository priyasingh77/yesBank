package com.slot1jdbc;

public class bankingcustomer {
	String cname;
	String cpassword;
	String cphone;
	int caccbal;

}
